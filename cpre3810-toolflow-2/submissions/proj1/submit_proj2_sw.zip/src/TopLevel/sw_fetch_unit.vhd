-------------------------------------------------------------------------
-- Shawn Robinson 
-------------------------------------------------------------------------


-- fetch_unit.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: Fetch unit ready for implementation, with functioning PC Register 
-------------------------------------------------------------------------


library IEEE;
use IEEE.std_logic_1164.all;

--library work;
--use work.RISCV_types.all;

entity sw_fetch_unit is
  generic(N : integer := 32);
  port(iCLK            		: in std_logic;
       iRST            		: in std_logic;
       i_target			: in std_logic_vector(31 downto 0); -- precomputed target
       i_taken			: in std_logic; 
       o_PC         		: out std_logic_vector(31 downto 0); --THIS WIRES DIRECTLY TO SKELETON s_PC! 
       Pc_plus4			: out std_logic_vector(31 downto 0)); 
end  sw_fetch_unit;


architecture structure of sw_fetch_unit is

	constant c_immediate_four 	: std_logic_vector(31 downto 0) := x"00000004"; 
	constant c_PC_RESET 		: std_logic_vector(31 downto 0) := x"00400000";
        


	signal s_pc_reg_input :		 std_logic_vector(31 downto 0);
	signal s_next_PC		: std_logic_vector(31 downto 0); 
	signal s_current_PC		: std_logic_vector(31 downto 0); 
	signal s_pc_plus4		: std_logic_vector(31 downto 0); 

	--handling a risc-v shift left one requirement
	signal s_imm_shifted		: std_logic_vector(31 downto 0); 
	

  component register_NBit is 
	generic(N: integer := 32); 
	port(D		: in std_logic_vector(N-1 downto 0); 
		RST	: in std_logic; 
		WE	: in std_logic; 
		CLK	: in std_logic; 
		Q	: out std_logic_vector(N-1 downto 0));
  end component;  		


  component andg2 is 
    port(i_A          : in std_logic;
       i_B          : in std_logic;
       o_F          : out std_logic);

  end component; 



  component pc_register is
  	port(	iCLK            	: in std_logic;
      		i_RST            	: in std_logic;
       		i_WE			: in std_logic;
       		i_D			: in std_logic_vector(31 downto 0); 
       		o_Q         		: out std_logic_vector(31 downto 0)); 
  end  component;


  component org2 is
    port(i_A          : in std_logic;
       i_B          : in std_logic;
       o_F          : out std_logic);

  end component; 

  
 component mux2t1_N is 
  generic(N : integer);
  port(i_S          : in std_logic;
       i_D0         : in std_logic_vector(N-1 downto 0);
       i_D1         : in std_logic_vector(N-1 downto 0);
       o_O          : out std_logic_vector(N-1 downto 0));

 end component;
 

  component carry_lookahead_adderN is
  generic(N : integer); 
  port(A         : in std_logic_vector(N-1 downto 0);
       B         : in std_logic_vector(N-1 downto 0);
       Cin       : in std_logic := '0';
       Sum	 : out std_logic_vector(N-1 downto 0);  
       Cout      : out std_logic); 

  end component;

begin
--  s_imm_shifted <= immediate_generate; 

  o_PC 		<= s_current_PC; 
  PC_plus4	<= s_pc_plus4; 
 -- s_pc_reg_input <= c_PC_RESET when iRST = '1' else s_next_PC;
  

   PC4_ADD:	carry_lookahead_adderN
	generic map(N => 32)
	port map(A	=> s_current_PC,
		 B	=> c_immediate_four,
		 Cin 	=> '0',
		 Sum	=> s_pc_plus4,
		 Cout	=> open);

   NEXT_PC_MUX: mux2t1_N
	generic map(N => 32)
	port map(i_S	=> i_taken,
		 i_D0	=> s_pc_plus4,
		 i_D1	=> i_target,
		 o_O	=> s_next_PC);

 -- RESET_MUX:	mux2t1_N
	--generic map(N => 32)
	--port map(i_S	=> iRST,
	-- 	 i_D0	=> s_next_PC,
	-- 	 i_D1	=> x"00400000", -- reset value 
	-- 	 o_O	=> s_pc_reg_input);
--
   ---PC_REG: pc_register
   	--generic map(N => 32)
   --	port map(iCLK => iCLK,
	--	 i_RST => iRST,
	--	 i_WE  => '1',
	--	 i_D   => s_pc_reg_input,
	--	 o_Q	=> s_current_PC);

RESET_MUX: mux2t1_N
    generic map(N => 32)
    port map(i_S  => iRST,
             i_D0 => s_next_PC,
             i_D1 => x"00400000",
             o_O  => s_pc_reg_input);

PC_REG: register_NBit
    generic map(N => 32)
    port map(D   => s_pc_reg_input,
             RST => '0',
             WE  => '1',
             CLK => iCLK,
             Q   => s_current_PC);

end structure;
