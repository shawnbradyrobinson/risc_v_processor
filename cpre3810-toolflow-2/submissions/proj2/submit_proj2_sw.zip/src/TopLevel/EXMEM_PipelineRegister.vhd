-------------------------------------------------------------------------
-- EXMEM_PipelineRegister.vhd
-------------------------------------------------------------------------
-- DESCRIPTION: ID/EX Pipeline Register for RISC-V 5-stage pipeline.
--
-------------------------------------------------------------------------

library IEEE; 
use IEEE.std_logic_1164.all; 

entity EXMEM_PipelineRegister is 

port(	iCLK: 		in std_logic;
	iRST: 		in std_logic;
	iWE:		in std_logic;  -- for stall control?
	--iFLUSH -- for squashing flushing eventually?

	--EX INPUTS: datapath 
	EX_PC:	  		in std_logic_vector(31 downto 0); 
	EX_Instr: 		in std_logic_vector(31 downto 0); 
	EX_PC_Plus4:		in std_logic_vector(31 downto 0);

	--EX_Branch_Taken:	in std_logic; --see what Jay does with branch resolver repositioning 
	EX_ALU_Result:		in std_logic_vector(31 downto 0);
	EX_rs2_out:		in std_logic_vector(31 downto 0);
	EX_rd_addr:		in std_logic_vector(4 downto 0);

	--EX INPUTS: control signals, mem-stage consumers --> 
	EX_MemWrite:		in std_logic;
	EX_MemRead:		in std_logic;
	

	--mem-stage consumers, fetch unit signals --
	EX_BranchTaken:		in std_logic;
	EX_Jump: 		in std_logic; 
	EX_PC_SRC:		in std_logic; 
	EX_rs1_out:		in std_logic_vector(31 downto 0); 
	EX_ImmGen:		in std_logic_vector(31 downto 0); 
	EX_Branch:		in std_logic; 
	

	
	--EX INPUTS: control signals, wb-stage consumers --> passing through 
	EX_RegWrite:		in std_logic;
	EX_MemToReg:		in std_logic_vector(1 downto 0);
	EX_Halt:		in std_logic; 


	--MEM OUTPUTS: datapath 
	MEM_PC:			out std_logic_vector(31 downto 0); 
	MEM_Instr:		out std_logic_vector(31 downto 0);
	MEM_PC_Plus4:		out std_logic_vector(31 downto 0);
	
	--MEM OUTPUTS: fetching 
	MEM_BranchTaken:	out std_logic;
	MEM_Jump:		out std_logic;
	MEM_PC_SRC:		out std_logic; 
	MEM_rs1_out:		out std_logic_vector(31 downto 0);
	MEM_Branch:		out std_logic;
	MEM_ImmGen:		out std_logic_vector(31 downto 0);

	--
	MEM_ALU_Result:		out std_logic_vector(31 downto 0);
	MEM_rs2_out:		out std_logic_vector(31 downto 0);
	MEM_rd_addr:		out std_logic_vector(4 downto 0);

	--MEM OUTPUTS: control
	MEM_Halt:		out std_logic; 
	MEM_MemWrite:		out std_logic;
	MEM_MemRead:		out std_logic;
	MEM_RegWrite:		out std_logic;
	MEM_MemToReg:		out std_logic_vector(1 downto 0)

); 

end EXMEM_PipelineRegister;

architecture structural of EXMEM_PipelineRegister is 

	component register_NBit is
    		generic(N : integer := 32);
    		port(	D   : in  std_logic_vector(N-1 downto 0);
         		RST : in  std_logic;
         		WE  : in  std_logic;
         		CLK : in  std_logic;
         		Q   : out std_logic_vector(N-1 downto 0));
  	end component;

	--Design idea: pack all the one bit control signals into a single vector register thing so we just write one 8-bit
	-- rather than a ton of one-bit instances
  	-- Bit assignments:
	-- 9: Halt
	-- 8: Branch
	-- 7: PC_SRC	
	-- 6: Jump
	-- 5: RegWrite
	-- 4: MemToReg(1)
	-- 3: MemToReg(0)
	-- 2: MemRead
	-- 1: MemWrite
	-- 0: BranchTaken
	signal s_ctrl_in	: std_logic_vector(9 downto 0);
	signal s_ctrl_out	: std_logic_vector(9 downto 0);

begin 


  -- Pack control inputs
  s_ctrl_in <= EX_Halt	   &
	       EX_Branch   &
	       EX_PC_SRC   &
	       EX_Jump     &
	       EX_RegWRite &
               EX_MemToReg &
               EX_MemRead  &
               EX_MemWrite &
	       EX_BranchTaken;

  -- Unpack control outputs
  MEM_Halt	<= s_ctrl_out(9);
  MEM_Branch	<= s_ctrl_out(8);
  MEM_PC_SRC	<= s_ctrl_out(7);
  MEM_Jump	<= s_ctrl_out(6);
  MEM_RegWrite  <= s_ctrl_out(5);
  MEM_MemToReg  <= s_ctrl_out(4 downto 3);
  MEM_MemRead   <= s_ctrl_out(2);
  MEM_MemWrite  <= s_ctrl_out(1);
  MEM_BranchTaken <= s_ctrl_out(0);

  REG_PC: register_NBit
    generic map(N => 32)
    port map(	D => EX_PC,         
		RST => iRST, 
		WE => iWE, 
		CLK => iCLK, 
		Q => MEM_PC);

   REG_Instr: register_NBit
    generic map(N => 32)
    port map(	D => EX_Instr,      
		RST => iRST, 
		WE => iWE, 
		CLK => iCLK, 
		Q => MEM_Instr);

   REG_ALU_Result: register_NBit
    generic map(N => 32)
    port map(	D => EX_ALU_Result, 
		RST => iRST, 
		WE => iWE, 
		CLK => iCLK, 
		Q => MEM_ALU_Result);

   REG_rs2: register_NBit
    generic map(N => 32)
    port map(	D => EX_rs2_out,    
		RST => iRST, 
		WE => iWE, 
		CLK => iCLK, 
		Q => MEM_rs2_out);

   REG_rs1: register_NBit
    generic map(N => 32)
    port map(	D => EX_rs1_out,
		RST => iRST,
		WE  => iWE,
		CLK => iCLK,
		Q   => MEM_rs1_out);

   REG_rd: register_NBit
    generic map(N => 5)
    port map(	D => EX_rd_addr,    
		RST => iRST, 
		WE => iWE, 
		CLK => iCLK, 
		Q => MEM_rd_addr);

   REG_PC_Plus4: register_NBit
    generic map(N => 32)
    port map(
        D   => EX_PC_Plus4,
        RST => iRST,
        WE  => iWE,
        CLK => iCLK,
        Q   => MEM_PC_Plus4
    );

    REG_IMM: register_NBit
    generic map(N => 32)
    port map(	D 	=> EX_ImmGen,
		RST	=> iRST,
		WE	=> iWE,
		CLK	=> iCLK,
		Q	=> MEM_ImmGen
	);

   REG_Ctrl: register_NBit
    generic map(N => 10)
    port map(	D => s_ctrl_in, 
		RST => iRST, 
		WE => iWE, 
		CLK => iCLK, 
		Q => s_ctrl_out);

end structural;



